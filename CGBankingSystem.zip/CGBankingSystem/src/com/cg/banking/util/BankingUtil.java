package com.cg.banking.util;

import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;

public class BankingUtil {
	private static long ACCOUNT_NUMBER=423200002;
	public static HashMap<Long,Account> accounts=new HashMap<>();
	
	public static long getACCOUNT_NUMBER() {
		return ++ACCOUNT_NUMBER;
	}

	public static HashMap<Integer, Transaction> transanctions=new HashMap<>();
	private static int TRANSACTION_ID=19300;

	public static int getTRANSACTION_ID() {
		return ++TRANSACTION_ID;
	}
	
}
