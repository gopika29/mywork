package com.cg.project.beans;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
public class PEmployee extends Employee{
	private int hra,da,ta;

	public PEmployee() {
		super();
	}

	
	public PEmployee(int employeeId, String firstName, String lastName) {
		super(employeeId, firstName, lastName);
	}


	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}
	
	
}
