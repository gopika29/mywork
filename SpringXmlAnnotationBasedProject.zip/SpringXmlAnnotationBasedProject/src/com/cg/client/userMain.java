package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.User;

public class userMain {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new 
				ClassPathXmlApplicationContext("cgXmlAnnotation.xml");
		System.out.println((User) applicationContext.getBean("user1"));
	}

}
