package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.IGreet;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new 
				ClassPathXmlApplicationContext("cgXmlAnnotation.xml");
		IGreet greet1=(IGreet) applicationContext.getBean("obj1");
		System.out.println("New year Greet "+greet1.greetMe());
		
		IGreet greet2=(IGreet) applicationContext.getBean("obj2");
		System.out.println("birthday greet "+greet2.greetMe());
	}

}
