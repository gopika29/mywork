package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;
import com.cg.bean.Employee2;

public class TestEmpAnnotationDemo {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new 
				ClassPathXmlApplicationContext("cgXmlAnnotation.xml");
		Employee emp1=(Employee) applicationContext.getBean("gopiEmp");
		System.out.println(emp1.toString());
		//for reference list
		Employee2 emp2=(Employee2) applicationContext.getBean("e2");
		System.out.println(emp2);
	}
}
