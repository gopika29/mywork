package com.cg.bean;

import org.springframework.beans.factory.annotation.Value;

public class NewYearWish implements IGreet{
	@Value("Gopika")
	private String firstName;
	@Value("2019")
	private int year;
	public NewYearWish() {
		System.out.println("new year wish constructor");
	}
	public NewYearWish(String firstName, int year) {
		super();
		this.firstName = firstName;
		this.year = year;
		System.out.println("new year wish parameterized constructor");
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	@Override
	public String greetMe() {
		return "happy New Year : "+year+" :"+firstName;
	}

}
