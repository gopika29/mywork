package com.cg.banking.main;

import java.io.FileNotFoundException;
import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.itextpdf.text.DocumentException;

public class MainClass {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner ip=new Scanner(System.in);
		BankingServices bankingServices=new BankingServicesImpl();
		int num=0;
		try {
			Account account1=bankingServices.openAccount("savings", 2000);
			Account account2=bankingServices.openAccount("current", 1000);
			while(num!=7) {
				System.out.println("\n1.deposit\n2.withdraw\n3.transfer\n4.getAccountDetails\n5.getAllAccounts"
						+ "\n6.getAllAccountTransaction\n7.exit\nenter number: ");
				num=ip.nextInt();
				switch (num) {
				case 1:
					System.out.println("enter money to deposit: ");
					System.out.println(bankingServices.depositAmount(account1.getAccountNo(), ip.nextInt()));
					break;
				case 2:
					System.out.println("enter money to withdraw: ");
					System.out.println(bankingServices.withdrawAmount(account1.getAccountNo(), ip.nextInt(), account1.getPinNumber()));
					break;
				case 3:
					System.out.println("enter money to transfer: ");
					System.out.println(bankingServices.fundTransfer(account2.getAccountNo(), account1.getAccountNo(), ip.nextInt(), 
							account1.getPinNumber()));
					break;
				case 4:
					System.out.println(bankingServices.getAccountDetails(account1.getAccountNo()));
					break;
				case 5:
					System.out.println(bankingServices.getAllAccountDetails());
					break;
				case 6:
					System.out.println(bankingServices.getAccountAllTransaction(account1.getAccountNo()));
					bankingServices.pdfGenerator(account1.getAccountNo());
					break;
				default:
					System.out.println("you entered default case");
					break;
				}
			}
			
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException | AccountNotFoundException | AccountBlockedException | InsufficientAmountException | InvalidPinNumberException | FileNotFoundException | DocumentException e) {
			e.printStackTrace();
		}
	}
}
