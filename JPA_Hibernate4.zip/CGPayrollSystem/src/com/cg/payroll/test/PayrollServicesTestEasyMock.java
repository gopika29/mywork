package com.cg.payroll.test;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
	/*private static PayrollServices payrollServices;
	private static AssociateDAO mockAssociateDao;
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao=EasyMock.createMock(AssociateDAO.class);//mock(AssociateDAO.class);
		payrollServices=new PayrollServicesImpl(mockAssociateDao);
	}
	@Before
	public void setUpTestMockData() {
		Associate associate1=new Associate(101, 200000, "gopi", "ankani", "java trainee", "analyst", "HAHI27979", "gopi@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(100086699, "HDFC", "hdfc997"));
		Associate associate2=new Associate(102, 190000, "sadhik", "shaik", "java trainee", "analyst", "HSD97979", "sadhik@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(10008808, "HDFC", "hdfc997"));
		Associate associate3=new Associate(123439,"sadhik","shaik","JEE","Trainee","HDHJJ3432","sadhik@gmail.com",
				new Salary(30000,1000,1000),new BankDetails(450748327,"CITI","CITI384073"));
		ArrayList<Associate> associatesList=new ArrayList<>();
		associatesList.add(associate1);
		associatesList.add(associate2);		
		EasyMock.expect(mockAssociateDao.save(associate3)).andReturn(associate3);
		
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
		EasyMock.expect(mockAssociateDao.findOne(123)).andReturn(null);
		EasyMock.expect(mockAssociateDao.findOne(103)).andReturn(associate3);
		EasyMock.replay(mockAssociateDao);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssoiciateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAsscoiateDetails(123);
		EasyMock.verify(mockAssociateDao.findOne(123));
	}
	@Test
	public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(103,123439,"sadhik","shaik","JEE","Trainee","HDHJJ3432","sadhik@gmail.com",
				new Salary(30000,1000,1000),new BankDetails(450748327,"CITI","CITI384073"));
		Associate actualAssociate=payrollServices.getAsscoiateDetails(103);
		Assert.assertEquals(expectedAssociate, actualAssociate);
		EasyMock.verify(mockAssociateDao.findOne(103));
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalcualteNetSalaryForInvalidAssociateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAsscoiateDetails(123);
		EasyMock.verify(mockAssociateDao.findOne(123));
	}
	@Test
	public void testCalcualteNetSalaryForvalidAssociateId()throws AssociateDetailsNotFoundException{
		float expectedNetSalary=38066.67f;
		Associate associate=payrollServices.getAsscoiateDetails(102);
		EasyMock.verify(mockAssociateDao.findOne(102));
		float actualNetSalary=payrollServices.calculateNetSalary(102);
		Assert.assertEquals(expectedNetSalary, actualNetSalary, 1000);
		EasyMock.verify(mockAssociateDao.update(associate));
	}
	@Test
	public void testForGetAllAssociateDetails() {
		ArrayList<Associate> expectedAssociateList=new ArrayList<>(PayrollUtil.associates.values());
		ArrayList<Associate> actualAssociateList=(ArrayList<Associate>) payrollServices.getAllAssociateDetails();
		EasyMock.verify(mockAssociateDao.findAll());
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
		
	}
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDao);
	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao=null;
		payrollServices=null;
	}*/
}
