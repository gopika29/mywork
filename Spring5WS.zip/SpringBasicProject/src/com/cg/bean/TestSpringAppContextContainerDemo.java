package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class TestSpringAppContextContainerDemo {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg.xml");
		System.out.println("--------birthday greet-----------");
		IGreet greet1=(IGreet)applicationContext.getBean("obj1");
		System.out.println(greet1.greetMe());
		System.out.println(greet1.hashCode());
		
		System.out.println("--------birthday greet with constructor injection-----------");
		IGreet greet2=(IGreet)applicationContext.getBean("obj3");
		System.out.println(greet2.greetMe());
		System.out.println(greet2.hashCode());
		
		System.out.println("--------New Year greet-----------");
		IGreet greet3=(IGreet)applicationContext.getBean("obj2");
		System.out.println(greet3.greetMe());
		System.out.println(greet3.hashCode());
		
		System.out.println("--------New Year greet-----------");
		IGreet greet4=(IGreet)applicationContext.getBean("obj2");
		System.out.println(greet4.greetMe());
		System.out.println(greet4.hashCode());
		
		System.out.println("--------New Year greet with Constructor injection-----------");
		IGreet greet5=(IGreet)applicationContext.getBean("obj4");
		System.out.println(greet5.greetMe());
		System.out.println(greet5.hashCode());
	}

}
