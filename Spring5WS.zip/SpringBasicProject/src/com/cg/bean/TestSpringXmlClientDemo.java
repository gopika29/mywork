package com.cg.bean;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@SuppressWarnings("deprecation")
public class TestSpringXmlClientDemo {
	public static void main(String[] args) {
		Resource resources=new ClassPathResource("cg.xml");
		BeanFactory beanFactory=new XmlBeanFactory(resources);
		IGreet birthDayGreet=(IGreet) beanFactory.getBean("obj1");
		System.out.println(birthDayGreet.greetMe());
	}
}
