package com.cg.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class BirthDayGreet implements IGreet,BeanNameAware,BeanFactoryAware
,DisposableBean,InitializingBean{
	private String firstName;
	public BirthDayGreet() {
	}
	
	public BirthDayGreet(String firstName) {
		super();
		this.firstName = firstName;
	}

	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		System.out.println("setFirstName() called");
	}
	@Override
	public String greetMe() {
		return "Happy BirthDay:"+firstName;
	}

	@Override
	public void setBeanName(String beanName) {
		System.out.println("In setBeanName() called.."+beanName);
		}

	@Override
	public void setBeanFactory(BeanFactory bf) throws BeansException {
		System.out.println("bean factory aware....."+bf.toString());
		
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("this is called after firstname set....");
	}

	@Override
	public void destroy() throws Exception {
		System.out.println("destroy is called");
	}
	
	public void cgInit() {
		System.out.println("this is custom cg init function");
	}
	
	public void cgDestroy() {
		System.out.println("this is custom cg destroy function");
	}
}
