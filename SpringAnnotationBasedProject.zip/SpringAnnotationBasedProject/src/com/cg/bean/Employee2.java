package com.cg.bean;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("e2")
public class Employee2 {
	@Value("120395")//to add from property file@value("id")
	private int empId;
	@Value("sadhik")
	private String empName;
	@Value("50000")
	private float empSal;
	@Resource(name="getAddressList")
	private ArrayList<Address> empAdd;
	public Employee2() {}
	public Employee2(int empId, String empName, float empSal, ArrayList<Address> empAdd) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		this.empAdd = empAdd;
	}
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	public ArrayList<Address> getEmpAdd() {
		return empAdd;
	}
	public void setEmpAdd(ArrayList<Address> empAdd) {
		this.empAdd = empAdd;
	}
	@Override
	public String toString() {
		return "Employee2 [empId=" + empId + ", empName=" + empName + ", empSal=" + empSal + ", empAdd=" + empAdd + "]";
	}
	
}
