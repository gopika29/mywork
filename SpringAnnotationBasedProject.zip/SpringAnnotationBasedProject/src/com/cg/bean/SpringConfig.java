package com.cg.bean;

import java.util.ArrayList;

import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
//configuration file// here we are using arraylist configuration
@Configuration
public class SpringConfig {
	@Bean
	public ArrayList<Address> getAddressList(){
		Address address1=new Address("Andhra", "West Godavari", 533244);
		Address address2=new Address("Telangana", "Hyderabad", 534233);
		ArrayList<Address> addressList=new ArrayList<>();
		addressList.add(address1);
		addressList.add(address2);
		return addressList;
	}
	@Bean
	public Address getOfficialAddress() {
		return new Address("Andhra", "srikakulam", 534342);
	}
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertuConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}
	
}
