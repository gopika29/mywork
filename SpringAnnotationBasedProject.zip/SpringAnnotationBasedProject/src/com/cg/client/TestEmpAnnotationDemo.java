package com.cg.client;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import com.cg.bean.Employee;
import com.cg.bean.Employee2;
@ComponentScan(basePackages="com.cg.bean")
public class TestEmpAnnotationDemo {
	public static void main(String[] args) {
		ApplicationContext applicationContext=SpringApplication.run(TestEmpAnnotationDemo.class, args);
		Employee emp1=(Employee) applicationContext.getBean("gopiEmp");
		System.out.println(emp1.toString());
		//for reference list
		Employee2 emp2=(Employee2) applicationContext.getBean("e2");
		System.out.println(emp2);
	}
}
