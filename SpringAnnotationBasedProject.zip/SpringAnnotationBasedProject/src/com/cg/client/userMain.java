package com.cg.client;

import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.User;
@ComponentScan(basePackages="com.cg.bean")
public class userMain {

	public static void main(String[] args) {
		ApplicationContext applicationContext=SpringApplication.run(userMain.class, args);
		System.out.println((User) applicationContext.getBean("user1"));
	}

}
