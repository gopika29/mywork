package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public class PayrollServicesImpl implements PayrollServices{
	private AssociateDAO associateDAO=new AssociateDAOImpl();

	/*private AssociateDAO associateDAO;
	public PayrollServicesImpl() {
		associateDAO=new AssociateDAOImpl();
	}
*/
	/*public PayrollServicesImpl(AssociateDAO associateDAO) {
		super();
		this.associateDAO = associateDAO;
	}*/

	@Override
	public int acceptAssociateDetails(Associate associate) {
		associate=associateDAO.save(associate);
		return associate.getAssociateID();
	}

	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=this.getAsscoiateDetails(associateId);
		associate.getSalary().setHra(associate.getSalary().getBasicSalary()*40/100);
		associate.getSalary().setConveyenceAllowance(associate.getSalary().getBasicSalary()*30/100);
		associate.getSalary().setPersonalAllowance(associate.getSalary().getBasicSalary()*20/100);
		associate.getSalary().setOtherAllowance(associate.getSalary().getBasicSalary()*20/100);
		associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getCompanypf()+associate.getSalary().getEpf()+associate.getSalary().getHra()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getPersonalAllowance());
		float annualGrossSalary=associate.getSalary().getGrossSalary()*12;
		float annualTax=taxCalculator(associateId, annualGrossSalary);
		associate.getSalary().setMonthlyTax(annualTax/12);
		associate.getSalary().setNetSalary(associate.getSalary().getGrossSalary()-associate.getSalary().getEpf()-associate.getSalary().getCompanypf()-associate.getSalary().getMonthlyTax());
		associateDAO.update(associate);
		return associate.getSalary().getNetSalary();
	}

	@Override
	public Associate getAsscoiateDetails(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate=associateDAO.findOne(associateId);
		if(associate==null)throw new AssociateDetailsNotFoundException("associate details not found for associate id "+associateId);
		return associate;
	}

	
	
	public float checkYearlyInvestmentUnder80C(int associateId,float annualGrossSalary) throws AssociateDetailsNotFoundException {
		Associate associate = this.getAsscoiateDetails(associateId);
		if(associate.getYearlyInvestementUnder80C()<=180000)
			annualGrossSalary=annualGrossSalary-associate.getYearlyInvestementUnder80C();
		else
			annualGrossSalary=annualGrossSalary+associate.getYearlyInvestementUnder80C()-180000;
		return annualGrossSalary;
	}
	public float taxCalculator(int associateId,float annualGrossSalary) throws AssociateDetailsNotFoundException {
		if(annualGrossSalary>0 && annualGrossSalary<=250000)
			return 0f;
		else if(annualGrossSalary>250000 && annualGrossSalary<=500000) {
			this.checkYearlyInvestmentUnder80C(associateId, annualGrossSalary);
			return (annualGrossSalary-250000)*10/100;
		}
		else if(annualGrossSalary>500000 && annualGrossSalary<=1000000) {
			this.checkYearlyInvestmentUnder80C(associateId, annualGrossSalary);
			return (annualGrossSalary-500000)*20/100+(annualGrossSalary-250000)*10/100;
		}
		else {
			this.checkYearlyInvestmentUnder80C(associateId, annualGrossSalary);
			return (annualGrossSalary-1000000)*30/100+(annualGrossSalary-500000)*20/100+(annualGrossSalary-250000)*10/100;
		}
	}

	@Override
	public List<Associate> getAllAssociateDetails() {
		return associateDAO.findAll();
	}
	
}
