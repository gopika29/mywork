package com.cg.payroll.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet("/controller")
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	PayrollServices payrollServices=new PayrollServicesImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if(request.getParameter("action").equals("registration")) {
		Associate associate=new Associate(Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C")), request.getParameter("firstName"), request.getParameter("lastName"),
				request.getParameter("password"), request.getParameter("department"), request.getParameter("designation"), request.getParameter("pancard"),request.getParameter("emailId") ,
				new Salary(Integer.parseInt(request.getParameter("basicSalary")), Integer.parseInt(request.getParameter("epf")), Integer.parseInt(request.getParameter("companyPf"))),
				new BankDetails(Integer.parseInt(request.getParameter("accountNumber")), request.getParameter("bankName"), request.getParameter("ifscCode")));
		payrollServices.acceptAssociateDetails(associate);
		RequestDispatcher dispatcher=request.getRequestDispatcher("registrationPage.jsp");
		request.setAttribute("associate", associate);
		dispatcher.forward(request, response);
		}
		else if(request.getParameter("action").equals("getAssociate")) {
			try {
				Associate associate=payrollServices.getAsscoiateDetails(Integer.parseInt(request.getParameter("associateId")));
				RequestDispatcher dispatcher=request.getRequestDispatcher("getOne.jsp");
				request.setAttribute("associate", associate);
				dispatcher.forward(request, response);
			} catch (AssociateDetailsNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(request.getParameter("action").equals("calculateNetSalary")) {
			try {
				Associate associate=payrollServices.getAsscoiateDetails(Integer.parseInt(request.getParameter("associateId")));
				payrollServices.calculateNetSalary(associate.getAssociateID());
				RequestDispatcher dispatcher=request.getRequestDispatcher("calculateSalary.jsp");
				request.setAttribute("associate",associate);
				dispatcher.forward(request, response);
			} catch (NumberFormatException | AssociateDetailsNotFoundException e) {
				e.printStackTrace();
			}
		}
		else if(request.getParameter("action").equals("getAll")) {
			List<Associate> associates=payrollServices.getAllAssociateDetails();
			RequestDispatcher dispatcher=request.getRequestDispatcher("getAllAssociateDetailsPage.jsp");
			request.setAttribute("associates", associates);
			dispatcher.forward(request, response);
		}
}
}
