package com.cg.electricitybilldaoservices;

import java.util.List;

import com.cg.electricitybillgeneration.beans.Customer;

public interface CustomerDao {
	Customer save(Customer customer);
	boolean update(Customer customer);
	Customer findOne(int customerNo);
	List<Customer> findAll();
}
