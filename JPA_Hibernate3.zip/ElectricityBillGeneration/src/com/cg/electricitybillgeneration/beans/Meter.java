package com.cg.electricitybillgeneration.beans;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class Meter {
	private int meterNo,consumptionUnits,meterLoad;
	private String phase;
	@Embedded
	private Bill bill;
	public Meter() {}
	public Meter(int meterNo, int consumptionUnits, int meterLoad, String phase) {
		super();
		this.meterNo = meterNo;
		this.consumptionUnits = consumptionUnits;
		this.meterLoad = meterLoad;
		this.phase = phase;
	}
	
	public Meter(int meterNo, int consumptionUnits, int meterLoad, String phase, Bill bill) {
		super();
		this.meterNo = meterNo;
		this.consumptionUnits = consumptionUnits;
		this.meterLoad = meterLoad;
		this.phase = phase;
		this.bill = bill;
	}
	public int getMeterNo() {
		return meterNo;
	}
	public void setMeterNo(int meterNo) {
		this.meterNo = meterNo;
	}
	public int getConsumptionUnits() {
		return consumptionUnits;
	}
	public void setConsumptionUnits(int consumptionUnits) {
		this.consumptionUnits = consumptionUnits;
	}
	public int getMeterLoad() {
		return meterLoad;
	}
	public void setMeterLoad(int meterLoad) {
		this.meterLoad = meterLoad;
	}
	public String getPhase() {
		return phase;
	}
	public void setPhase(String phase) {
		this.phase = phase;
	}
	public Bill getBill() {
		return bill;
	}
	public void setBill(Bill bill) {
		this.bill = bill;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bill == null) ? 0 : bill.hashCode());
		result = prime * result + consumptionUnits;
		result = prime * result + meterLoad;
		result = prime * result + meterNo;
		result = prime * result + ((phase == null) ? 0 : phase.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Meter other = (Meter) obj;
		if (bill == null) {
			if (other.bill != null)
				return false;
		} else if (!bill.equals(other.bill))
			return false;
		if (consumptionUnits != other.consumptionUnits)
			return false;
		if (meterLoad != other.meterLoad)
			return false;
		if (meterNo != other.meterNo)
			return false;
		if (phase == null) {
			if (other.phase != null)
				return false;
		} else if (!phase.equals(other.phase))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Meter [meterNo=" + meterNo + ", consumptionUnits=" + consumptionUnits + ", meterLoad=" + meterLoad
				+ ", phase=" + phase + bill.toString();
	}
	
}
