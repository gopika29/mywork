package com.cg.electricitybillgeneration.beans;

import javax.persistence.Embeddable;

@Embeddable
public class Bill {
	private int billNo,fixedCharge;
	private String billdate,billMonth,billUnit;
	float billAmount,energyDuty,energyTax;
	public Bill() {}
	public Bill(int billNo, String billdate,String billUnit, String billMonth) {
		super();
		this.billNo = billNo;
		this.billdate = billdate;
		this.billUnit = billUnit;
		this.billMonth = billMonth;
	}
	public int getBillNo() {
		return billNo;
	}
	public void setBillNo(int billNo) {
		this.billNo = billNo;
	}
	public float getBillAmount() {
		return billAmount;
	}
	public void setBillAmount(float billAmount) {
		this.billAmount = billAmount;
	}
	public String getBilldate() {
		return billdate;
	}
	public void setBilldate(String billdate) {
		this.billdate = billdate;
	}

	public String getBillUnitsConsumed() {
		return billUnit;
	}
	public void setBillUnitsConsumed(String billUnit) {
		this.billUnit = billUnit;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	public int getFixedCharge() {
		return fixedCharge;
	}
	public void setFixedCharge(int fixedCharge) {
		this.fixedCharge = fixedCharge;
	}
	public String getBillUnit() {
		return billUnit;
	}
	public void setBillUnit(String billUnit) {
		this.billUnit = billUnit;
	}
	public float getEnergyDuty() {
		return energyDuty;
	}
	public void setEnergyDuty(float energyDuty) {
		this.energyDuty = energyDuty;
	}
	public float getEnergyTax() {
		return energyTax;
	}
	public void setEnergyTax(float energyTax) {
		this.energyTax = energyTax;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((billMonth == null) ? 0 : billMonth.hashCode());
		result = prime * result + billNo;
		result = prime * result + ((billUnit == null) ? 0 : billUnit.hashCode());
		result = prime * result + ((billdate == null) ? 0 : billdate.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bill other = (Bill) obj;
		if (billMonth == null) {
			if (other.billMonth != null)
				return false;
		} else if (!billMonth.equals(other.billMonth))
			return false;
		if (billNo != other.billNo)
			return false;
		if (billUnit == null) {
			if (other.billUnit != null)
				return false;
		} else if (!billUnit.equals(other.billUnit))
			return false;
		if (billdate == null) {
			if (other.billdate != null)
				return false;
		} else if (!billdate.equals(other.billdate))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Bill [billNo=" + billNo + ", fixedCharge=" + fixedCharge + ", billdate=" + billdate + ", billMonth="
				+ billMonth + ", billUnit=" + billUnit + ", billAmount=" + billAmount + ", energyDuty=" + energyDuty
				+ ", energyTax=" + energyTax +  "]";
	}
	
	
	
}
