package com.cg.inheritance.beans;

public class PEmployee extends Employee{
	private int hra,da,ta;

	public PEmployee() {
		super();
	}

	public PEmployee(int employeeId, int basicSalary, String firstName, String lastName) {
		super(employeeId, basicSalary, firstName, lastName);
	}
	
	
	public int getHra() {
		return hra;
	}

	public void setHra(int hra) {
		this.hra = hra;
	}

	public int getDa() {
		return da;
	}

	public void setDa(int da) {
		this.da = da;
	}

	public int getTa() {
		return ta;
	}

	public void setTa(int ta) {
		this.ta = ta;
	}

	

	public void calculateSalary() {
		hra=getBasicSalary()*10/100;
		ta=getBasicSalary()*10/100;
		da=getBasicSalary()*10/100;
		this.setTotalSalary(hra+da+ta+getBasicSalary());
		
	}

	@Override
	public String toString() {
		return super.toString()+",hra=" + hra + ", da=" + da + ", ta=" + ta ;
	}
	
	
	
}
