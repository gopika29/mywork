function validateRegistrationForm() {
if(registerForm.firstName.value==""){
		document.getElementById("firstName").innerHTML="enter first name";
		return false;
	}
	if(registerForm.lastName.value==""){
		document.getElementById("lastName").innerHTML="enter last name";
		return false;
	}
	if(registerForm.emailId.value==""){
		document.getElementById("emailId").innerHTML="enter email";
		return false;
	}
	if(registerForm.department.value==""){
		document.getElementById("department").innerHTML="enter department";
		return false;
	}
	if(registerForm.designation.value==""){
		document.getElementById("designation").innerHTML="enter designation";
		return false;
	}
	if(registerForm.pancard.value==""){
		document.getElementById("pancard").innerHTML="enter pan no";
		return false;
	}
	if(registerForm.yearlyInvestmentUnder80C.value==""){
		document.getElementById("yearlyInvestmentUnder80C").innerHTML="enter yearlyInvestmentUnder80C";
		return false;
	}
	if(registerForm.basicSalary.value==""){
		document.getElementById("basicSalary").innerHTML="enter basic salary";
		return false;
	}
	if(registerForm.epf.value==""){
		document.getElementById("epf").innerHTML="enter epf amount";
		return false;
	}
	if(registerForm.companyPf.value==""){
		document.getElementById("companyPf").innerHTML="enter companypf amount";
		return false;
	}
	if(registerForm.accountNumber.value==""){
		document.getElementById("accountNumber").innerHTML="enter account Number";
		return false;
	}
	if(registerForm.bankName.value==""){
		document.getElementById("bankName").innerHTML="enter bank name";
		return false;
	}
	if(registerForm.ifscCode.value==""){
		document.getElementById("ifscCode").innerHTML="enter ifsc code";
		return false;
	}
	else{
		return true;
	}
	
}
