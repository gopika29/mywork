package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/registration")
public class RegistrationServelt extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String emailId=request.getParameter("emailId");
		String department=request.getParameter("department");
		String designation=request.getParameter("designation");
		String pancard=request.getParameter("pancard");
		int yearlyInvestmentUnder80C=Integer.parseInt(request.getParameter("yearlyInvestmentUnder80C"));
		int basicSalary=Integer.parseInt(request.getParameter("basicSalary"));
		int epf=Integer.parseInt(request.getParameter("epf"));
		int companyPf=Integer.parseInt(request.getParameter("companyPf"));
		int accountNumber=Integer.parseInt(request.getParameter("accountNumber"));
		String bankName=request.getParameter("bankName");
		String ifscCode=request.getParameter("ifscCode");
		out.println("<html><body>");
		out.println("<div align='center'><font size='25px' color='peach'>");
		out.println("firstName: "+firstName+"<br>lastName: "+lastName+"<br>emailId: "+emailId+"<br>department: "+department+
				"<br>designation: "+designation+"<br>pancard: "+pancard+"<br>yearlyInvestmentUnder80C: "+
				yearlyInvestmentUnder80C+"<br>basicSalary: "+basicSalary+"<br>epf: "+epf+"<br>companyPf: "+companyPf+
				"<br>accountNumber: "+accountNumber+"<br>bankName: "+bankName+"<br>ifscCode: "+ifscCode);
		out.println("</font></div></body></html>");
	}

}
