package com.cg.project.bean;

public class UserBean {
	private int associateId;
	private String password;
	public UserBean() {
	}
	public UserBean(int associateId, String password) {
		super();
		this.associateId = associateId;
		this.password = password;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
