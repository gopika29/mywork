package com.cg.stepdefinitions;

import static org.testng.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import com.cg.pagebean.HotelBookingPageFactory;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class HotelBookingStepDefinition {

	static WebDriver driver;
	private HotelBookingPageFactory hotelBookingPageFactory;

	@Before
	public void openBrowser() {
	//	driver = new FirefoxDriver();
		String driverPath = "D:\\Selenium\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
	
	//	hotelBookingPageFactory=new HotelBookingPageFactory(driver);
	//	driver.get("file:///D:/Selenium/Lesson%205-HTML%20Pages/App/hotelbooking.html");

	}

	@Given("^User is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
	

		hotelBookingPageFactory = new HotelBookingPageFactory(driver);
		driver.get("file:///D:/Selenium/Lesson%205-HTML%20Pages/App/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Hotel Booking")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		
	}
	
	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7834567372");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Pune");	Thread.sleep(100);
		hotelBookingPageFactory.setPfstate("Maharashtra");	Thread.sleep(100);
		hotelBookingPageFactory.setPfpersons(5);	Thread.sleep(100);
		hotelBookingPageFactory.setPfcardholder("Aanchal Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfDebit("5678567867897890");	Thread.sleep(100);
		hotelBookingPageFactory.setPfCvv("067");	Thread.sleep(100);
		hotelBookingPageFactory.setPfMonth("5");	Thread.sleep(100);
		hotelBookingPageFactory.setPfYear("2020"); 
	//	driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		hotelBookingPageFactory.setPfbutton();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("file:///D:/Selenium/Lesson%205-HTML%20Pages/App/success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}
	
	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
		hotelBookingPageFactory.setPffname("");	
		
	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfbutton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(500);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	   
	}
	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Throwable {
	
		hotelBookingPageFactory.setPffname("Aanchal");	
		hotelBookingPageFactory.setPflname("");	
		hotelBookingPageFactory.setPfbutton();
	}
	@When("^user enters all data$")
	public void user_enters_all_data() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7834567372");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Pune");	Thread.sleep(100);
		hotelBookingPageFactory.setPfstate("Maharashtra");	Thread.sleep(100);
		hotelBookingPageFactory.setPfpersons(5);	Thread.sleep(100);
		hotelBookingPageFactory.setPfcardholder("Aanchal Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfDebit("5671234567899876");	Thread.sleep(100);
		hotelBookingPageFactory.setPfCvv("056");	Thread.sleep(100);
		hotelBookingPageFactory.setPfMonth("9");	Thread.sleep(100);
		hotelBookingPageFactory.setPfYear("2020");	Thread.sleep(100);
	}

	@When("^user enters incorrect email format and clicks the button$")
	public void user_enters_incorrect_email_format_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfemail("Aa7@.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfbutton();
	}
	
	@When("^user leaves MobileNo blank and clicks the button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("");	Thread.sleep(100);
		hotelBookingPageFactory.setPfbutton();
	}

	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
				
		List<String> objList = arg1.asList(String.class);
		//objhbpg.setPfmobile(objList);	Thread.sleep(1000);
		hotelBookingPageFactory.setPfbutton();
		
		for(int i=0; i<objList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
			System.out.println("***** Matched" + objList.get(i) + "*****");
			}
			else {
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
			}
		}
	}
	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7722005480");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Select City");	Thread.sleep(100);
		hotelBookingPageFactory.setPfbutton();
	}

	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7722005480");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Pune");	Thread.sleep(100);
		hotelBookingPageFactory.setPfstate("Select State");	Thread.sleep(100);
		hotelBookingPageFactory.setPfbutton();
	}
	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7722005480");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Pune");	Thread.sleep(100);
		hotelBookingPageFactory.setPfstate("Maharashtra");	Thread.sleep(100);
		hotelBookingPageFactory.setPfpersons(arg1);	Thread.sleep(100);
	
	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
		if(arg2 <=3) {
	    	System.out.println("***** 1 room");
	    	assertEquals(1, arg1);
	    }
	    else if(arg2 <=6){
	    	System.out.println("***** 2 rooms");
	    	assertEquals(2, arg1); 	
	    }	 
	    else if(arg2 <=9){
	    	System.out.println("***** 3 rooms");
	    	assertEquals(3, arg1); 	
	    }
	}

	@When("^user leaves CardHolderName blank and clicks the button$")
	public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7722005480");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Pune");	Thread.sleep(100);
		hotelBookingPageFactory.setPfstate("Maharashtra");	Thread.sleep(100);
		hotelBookingPageFactory.setPfpersons(7);	Thread.sleep(100);
		hotelBookingPageFactory.setPfcardholder("");	Thread.sleep(100);
		hotelBookingPageFactory.setPfbutton();
	}

	@When("^user leaves DebitCardNo blank and clicks the button$")
	public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7722005480");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Pune");	Thread.sleep(100);
		hotelBookingPageFactory.setPfstate("Maharashtra");	Thread.sleep(100);
		hotelBookingPageFactory.setPfpersons(7);	Thread.sleep(100);
		hotelBookingPageFactory.setPfcardholder("Aanchal Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfDebit("");	Thread.sleep(100);
		hotelBookingPageFactory.setPfbutton();
	} 

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7722005680");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Pune");	Thread.sleep(100);
		hotelBookingPageFactory.setPfstate("Maharashtra");	Thread.sleep(100);
		hotelBookingPageFactory.setPfpersons(7);	Thread.sleep(100);
		hotelBookingPageFactory.setPfcardholder("Aanchal Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfDebit("8765431234567898");	Thread.sleep(100);
		hotelBookingPageFactory.setPfCvv("098");	Thread.sleep(100);
		hotelBookingPageFactory.setPfMonth("");	Thread.sleep(100);
		hotelBookingPageFactory.setPfbutton();
	}

	@When("^user leaves expirationYr blank and clicks the button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPffname("Aanchal");	Thread.sleep(100);
		hotelBookingPageFactory.setPflname("Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfemail("aanchal26@gmail.com");	Thread.sleep(100);
		hotelBookingPageFactory.setPfmobile("7722005680");	Thread.sleep(100);
		hotelBookingPageFactory.setPfcity("Pune");	Thread.sleep(100);
		hotelBookingPageFactory.setPfstate("Maharashtra");	Thread.sleep(100);
		hotelBookingPageFactory.setPfpersons(7);	Thread.sleep(100);
		hotelBookingPageFactory.setPfcardholder("Aanchal Srivastava");	Thread.sleep(100);
		hotelBookingPageFactory.setPfDebit("7678567867897890");	Thread.sleep(100);
		hotelBookingPageFactory.setPfCvv("056");	Thread.sleep(100);
		hotelBookingPageFactory.setPfMonth("8");	Thread.sleep(100);
		hotelBookingPageFactory.setPfYear("");	Thread.sleep(100);
		hotelBookingPageFactory.setPfbutton();
	}


	@After
	public void closeBrowser() {
		driver.close();
	}
}


