package com.cg.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.bean.Employee;
import com.cg.bean.Employee1;
import com.cg.bean.SbuWithEmployeeListReference;

public class MainClass {

	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cg.xml");
		System.out.println("----Setter getter Injection-------");
		Employee employee=(Employee) applicationContext.getBean("obj1");
		System.out.println("-------Employee Details--------");
		System.out.println("Employee Id: "+employee.getEmployeeId()+"\nEmployee Name: "+employee.getEmployeeName()
		+"\nEmployee Salary: "+employee.getSalary()+"\nBusiness Unit: "+employee.getBusinessUnit()+
		"\nEmployee Age: "+employee.getAge());
		System.out.println("----Constructor Injection-------");
		Employee employee1=(Employee) applicationContext.getBean("obj2");
		System.out.println("-------Employee Details--------");
		System.out.println("Employee Id: "+employee1.getEmployeeId()+"\nEmployee Name: "+employee1.getEmployeeName()
		+"\nEmployee Salary: "+employee1.getSalary()+"\nBusiness Unit: "+employee1.getBusinessUnit()+
		"\nEmployee Age: "+employee1.getAge());
		//sbu refernce variable
		ApplicationContext applicationContext2=new ClassPathXmlApplicationContext("cg1.xml");
		Employee1 employee2=(Employee1) applicationContext2.getBean("obj1");
		System.out.println(employee2);
		//sbu with EmployeeList Reference
		System.out.println(applicationContext.getBean("obj3"));
	}

}
