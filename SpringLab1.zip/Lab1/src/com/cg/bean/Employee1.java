package com.cg.bean;

public class Employee1 {
	private int employeeId;
	private String employeeName;
	private double salary;
	private SBU sbuDetails;
	private int age;
	public Employee1() {
	}
	
	public Employee1(int employeeId, String employeeName, double salary, SBU sbuDetails, int age) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.salary = salary;
		this.sbuDetails = sbuDetails;
		this.age = age;
	}

	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}

	public SBU getSbuDetails() {
		return sbuDetails;
	}

	public void setSbuDetails(SBU sbuDetails) {
		this.sbuDetails = sbuDetails;
	}

	@Override
	public String toString() {
		return "Employee1 [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary
				+ ", sbuDetails=" + sbuDetails + ", age=" + age + "]";
	}
	
}
