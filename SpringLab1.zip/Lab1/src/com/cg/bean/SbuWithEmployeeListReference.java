package com.cg.bean;

import java.util.ArrayList;

public class SbuWithEmployeeListReference {
	private String sbuId;
	private String sbuName;
	private String sbuHead;
	private ArrayList<Employee> employees;
	public SbuWithEmployeeListReference() {}
	public SbuWithEmployeeListReference(String sbuId, String sbuName, String sbuHead, ArrayList<Employee> employees) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.employees = employees;
	}
	public String getSbuId() {
		return sbuId;
	}
	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getSbuHead() {
		return sbuHead;
	}
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}
	public ArrayList<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(ArrayList<Employee> employees) {
		this.employees = employees;
	}
	@Override
	public String toString() {
		return "SbuWithEmployeeListReference [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead
				+ ", employees=" + employees + "]";
	}
	
}
