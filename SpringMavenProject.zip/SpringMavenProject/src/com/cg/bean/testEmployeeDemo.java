package com.cg.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class testEmployeeDemo {
	public static void main(String[] args) {
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("cgBean.xml");
		Employee emp1=(Employee) applicationContext.getBean("gopiEmpObj");
		System.out.println("-----Emp Info-------");
		System.out.println("ID: "+emp1.getEmpId()+"\nName: "+emp1.getEmpName()+"\nSalary: "+emp1.getEmpSal()
		+"\n---Employee Adress---\nState: "+emp1.getEmpAdd().getState()+"\nCity: "+emp1.getEmpAdd().getCity()
		+"\nZipCode: "+emp1.getEmpAdd().getZipCode());
		Employee2 emp2=(Employee2) applicationContext.getBean("sadhikEmpObj");
		System.out.println("-----Sadhik Info-------");
		System.out.println("ID: "+emp2.getEmpId()+"\nName: "+emp2.getEmpName()+"\nSalary: "+emp2.getEmpSal()
		+"\n---Employee Adress---\nState: "+emp2.getEmpAdd());
	}

}
