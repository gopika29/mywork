package com.cg.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.bean.Login;
import com.cg.bean.Register;
import com.cg.service.LoginService;
@Controller
public class LoginController {
	@Autowired
	LoginService loginService;

	public LoginService getLoginService() {
		return loginService;
	}
	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}

	@RequestMapping(value="/loginPage",method=RequestMethod.GET)
	public String displayLoginPage(Model model) {
		model.addAttribute("login",new Login());
		model.addAttribute("compNameObj", "Capgemini");
		return "LoginPage";
	}
	//------------------------validate user------------------------------
	@RequestMapping(value="/validateUser",method=RequestMethod.POST)
	public String validateUserDetails(@ModelAttribute(value="login") @Valid Login login,BindingResult result,
			Model model) {
		if(result.hasErrors())
			return "LoginPage";
		else {
			if(loginService.isUserExist(login.getUserName())) {
				if(loginService.validateUser(login)!=null) {
					model.addAttribute("success","Login Success");
					return "LoginPage";
				}
				else
					model.addAttribute("failure", "your username or password are wrong");
				return "LoginPage";
			}else {
				return "redirect:/registerPage.obj";
			}
		}
	}

	@ModelAttribute("skillSet")
	public ArrayList<String> createSkillSet() {
		ArrayList<String> skillSet=new ArrayList<>();
		skillSet.add("JAVA");
		skillSet.add("Oracle");
		skillSet.add("Html");
		skillSet.add("BI");
		return skillSet;
	}
	@ModelAttribute("cityList")
	public ArrayList<String> createCityList(){
		ArrayList<String> cityList=new ArrayList<>();
		cityList.add("HyderBad");
		cityList.add("Vijayawada");
		cityList.add("Banglore");
		cityList.add("Vizag");
		return cityList;
	}
	//-----------------------show registration page--------------------------------
	@RequestMapping(value="/registerPage",method=RequestMethod.GET)//method is optional here
	public String displayRegisterPage(Model model,
			@ModelAttribute(value="skillSet") ArrayList<String> skillSet,
			@ModelAttribute(value="cityList") ArrayList<String> cityList) {
		model.addAttribute("register", new Register());
		model.addAttribute("cityList", cityList);
		model.addAttribute("skillSet",skillSet);
		return "RegisterPage";
	}
	//-----------------------Insert User----------------------------------
	@RequestMapping(value="InsertUser",method=RequestMethod.POST)
	public String addUserDetails(@ModelAttribute(value="register") @Valid Register register,
			BindingResult result,Model model) {
		if(result.hasErrors())
			return "RegisterPage";
		model.addAttribute("register",loginService.insertUserDetails(register));
		return "ListAllUser";
	}
}
