package com.cg.dao;

import com.cg.bean.Login;
import com.cg.bean.Register;

public interface LoginDao {
	public boolean isUserExist(String userName);
	public Login validateUser(Login login);
	public Register insertUserDetails(Register register);
}
