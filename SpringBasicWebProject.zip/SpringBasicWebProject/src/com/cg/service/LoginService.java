package com.cg.service;

import com.cg.bean.Login;
import com.cg.bean.Register;

public interface LoginService {
	public boolean isUserExist(String userName);
	public Login validateUser(Login login);
	public Register insertUserDetails(Register register);
}
