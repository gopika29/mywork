package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Login;
import com.cg.bean.Register;
import com.cg.dao.LoginDao;
@Service("loginService")
public class LoginServiceImpl implements LoginService{
	@Autowired
	LoginDao loginDao;
	@Override
	public boolean isUserExist(String userName) {
		return loginDao.isUserExist(userName);
	}

	@Override
	public Login validateUser(Login login) {
		if(login.getUserName().equalsIgnoreCase(loginDao.validateUser(login).getUserName())&&
				login.getPassword().equalsIgnoreCase(loginDao.validateUser(login).getPassword()))
			return login;
		return null;
	}

	public LoginDao getLoginDao() {
		return loginDao;
	}

	public void setLoginDao(LoginDao loginDao) {
		this.loginDao = loginDao;
	}

	@Override
	public Register insertUserDetails(Register register) {
		return loginDao.insertUserDetails(register);
	}

}
